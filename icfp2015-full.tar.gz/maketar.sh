tar -cf icfp2015.tar.gz *.sh *.hs *.cpp *.h Makefile README
