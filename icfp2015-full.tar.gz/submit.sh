curl --user :27avHFT9+FbtJpEYwNZ8MMNm4PfnThpi++tXnAbCIlg= -X POST -H "Content-Type: application/json" -d @$1 https://davar.icfpcontest.org/teams/3/solutions
